#ifndef CATALOGUE_H
#define CATALOGUE_H
/////////////////////////////////////////////////////////////////////////////
// Catalogue.h - Analysis and fulfill user commands                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Language:    Visual C++, Visual Studio 2013                             //
// Platform:    Lenovo Y410p, Core i7, Windows 7 SP1                       //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
//              (315) 396-3866, siye@syr.edu                               //
/////////////////////////////////////////////////////////////////////////////
#include "FileMgr.h"
#include <iostream>


class Catalogue{
public:
	static void process(FileMgr &, DataStore &, const std::string& getuserinput);
	static void processD(FileMgr &fm, const std::string& getuserinput);
	static void processF(FileMgr &, DataStore &, const std::string& getuserinput);
	static void searchText(FileMgr &, DataStore &, const std::string& text);
	static std::string readText(const std::string &filespec);
	static std::string fInLoop(const std::string& getuserinput);
	static void loop(FileMgr &fm, DataStore &ds);
};


#endif