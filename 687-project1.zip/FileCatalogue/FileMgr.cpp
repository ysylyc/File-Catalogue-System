
// FileMgr.cpp - Collects file specifications from directory tree

#include "FileMgr.h"
#include <iostream>

// onOroff is a switch to control the search is recursion or not
void FileMgr::initializeSearch(int onOroff)
{
	find(path_, onOroff);
}
void FileMgr::find(const std::string& path, int onOroff)
{
	for (auto patt : patterns_)
	{
		std::vector<std::string> files = FileSystem::Directory::getFiles(path, patt);
		for (auto f : files)
		{
			// get filespec
			std::string temp = path + "\\" + f;
			temp = FileSystem::Path::getFullFileSpec(temp);
			store_.save(temp);
		}
		std::vector<std::string> dirs = FileSystem::Directory::getDirectories(path);

		// remove "." and ".." from dirs

		auto iter = std::find(std::begin(dirs), std::end(dirs), ".");
		if (iter != std::end(dirs))
		{
			dirs.erase(iter);
		}
		iter = std::find(std::begin(dirs), std::end(dirs), "..");
		if (iter != std::end(dirs))
		{
			dirs.erase(iter);
		}
		if (onOroff == 1){
			// recur the whole file tree
			for (auto d : dirs)
			{
				std::string temp = path;
				temp = temp + "\\" + d;
				find(temp, onOroff);
			}
		}
	}
}

// put all patterns into one string
std::string FileMgr::getPatt(){
	std::string allPatt = "";
	for (auto patt : patterns_){
		allPatt += patt;
	}
	return allPatt;
}

// ----< test stub >--------------------------------------------------------
#ifdef TEST_FILEMGR

int main()
{
	std::cout << "\n  Testing FileMgr class";
	std::cout << "\n =======================\n";

	DataStore ds;
	FileMgr fm(".", ds);
	fm.addPattern("*.h");
	fm.addPattern("*.cpp");
	fm.addPattern("*.obj");
	fm.initializeSearch();
	for (auto item : fm)
	{
		std::cout << "\n  " << item;
	}
	std::cout << "\n  Testing getPatt function";
	std::cout << "\n =======================\n";
	std::string patt = getPatt();
	std::cout << patt;
	std::cout << "\n  Testing recoverPattern function";
	std::cout << "\n =======================\n";
	recoverPattern();
	std::cout << patt = getPatt();
	std::cout << "\n\n";
	return 0;
}

#endif