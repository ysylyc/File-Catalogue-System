#ifndef EXEC_H
#define EXEC_H
/////////////////////////////////////////////////////////////////////////////
// Exec.h - Get input from user and set basic parameters                   //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "FileMgr.h"
#include <iostream>
#include <vector>
#include <string>

class Exec{
public:
	static bool findstr(const std::string& getuserinput, const std::string& str);
	static std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems);
	static std::string getpath(const std::string& getuserinput);
	static void checkPath(std::string& path);
	static void setpatt(FileMgr &, const std::string& getuserinput);
	static void checkPatt(std::string& patt);
};

#endif