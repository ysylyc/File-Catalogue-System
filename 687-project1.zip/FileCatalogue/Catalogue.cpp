/////////////////////////////////////////////////////////////////////////////
// Catalogue.h - Analysis and fulfill user commands                        //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Language:    Visual C++, Visual Studio 2013                             //
// Platform:    Lenovo Y410p, Core i7, Windows 7 SP1                       //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
//              (315) 396-3866, siye@syr.edu                               //
/////////////////////////////////////////////////////////////////////////////

#include "Catalogue.h"
#include "Exec.h"
#include "Display.h"
#include <string>

// Initialize DataStore and assign tasks to each function
void Catalogue::process(FileMgr &fm, DataStore &ds, const std::string& getuserinput){
	if (Exec::findstr(getuserinput, " /s")){
		//if found, do a recursion search
		fm.initializeSearch(1);
	}
	else{
		fm.initializeSearch(0);	
	}
	// DEFAULT summary
	Display::summary(ds.getFileNum(), ds.getDirNum(), Display::DEFAULT);
	// process /d command
	processD(fm, getuserinput);
	// process /f command
	processF(fm, ds, getuserinput);
}

// Take care of command "/d"
void Catalogue::processD(FileMgr &fm, const std::string& getuserinput){
	if (Exec::findstr(getuserinput, " /d")){
		//if found
		size_t fileNum = 0;
		for (auto tempFilename : fm){
			if (tempFilename.second.size() > 1){
				// count file quantity
				fileNum += tempFilename.second.size();
				// output result
				Display::printResultD(tempFilename.first, tempFilename.second);
			}
		}
		// DUPLICATION summary
		Display::summary(fileNum, fileNum, Display::DUPLICATION);
	}
	else return;
}

// Take care of command "/f"
void Catalogue::processF(FileMgr &fm, DataStore &ds, const std::string& getuserinput){
	if (Exec::findstr(getuserinput, "/f\"")){
		//if found, get the searched text
		std::string text;
		std::vector<std::string> searchedText;
		// split user input depends on "
		Exec::split(getuserinput, '"', searchedText);
		// get the text
		for (size_t i = 0; i < searchedText.size(); i++){
			if (Exec::findstr(searchedText[i], "/f")){
				i++;
				text = searchedText[i];
				break;
			}
		}
		searchText(fm, ds, text);
	}
}

// Search text from files
void Catalogue::searchText(FileMgr &fm, DataStore &ds, const std::string& text){
	// initialize file and directory number
	int fileNum = 0;
	std::set<std::string> dirNum;
	// put all patt into one string for easily matching
	std::string patt = fm.getPatt();
	std::cout << "=========list of files("<< patt <<") which contain \"" << text << "\"=========\n";
	// an iterator of DataStore
	for (auto i : ds){
		// an iterator of list
		for (auto j : i.second){
			// only search the file which match the patterns
			if (Exec::findstr(patt, FileSystem::Path::getExt(*j + i.first)) || patt == "*.*"){
				// put the content of file into one string
				std::string content = readText(*j + i.first);
				if (Exec::findstr(content, text)){
					// if found, output the result immediately
					Display::printResultF(i.first, *j);
					// record file and directory number
					fileNum++;
					dirNum.insert(*j);
				}
			}
		}
	}
	if (fileNum == 0){
		std::cout << "No such file found in this catalog.\n";
	}
	else{
		// SEARCHED summary
		Display::summary(fileNum, dirNum.size(), Display::SEARCHED);
	}
}

// Read from a filespec, and put them in one string
std::string Catalogue::readText(const std::string &filespec){
	FileSystem::File fileread(filespec);
	fileread.open(FileSystem::File::in);
	if (fileread.isGood()){
		std::string all = fileread.readAll(true);
		fileread.close();
		return all;
	}
	fileread.close();
	return 0;
}

// In second step loop, take care of search even without "/f"
std::string Catalogue::fInLoop(const std::string& userinput){
	// find the first "
	size_t p1 = userinput.find('"');
	// find the last "
	size_t p2 = userinput.rfind('"');
	// get the content between double quotes
	std::string textSearched = userinput.substr(p1 + 1, p2 - p1 - 1);
	return textSearched;
}

// Loop after construction of the catalog
void Catalogue::loop(FileMgr &fm, DataStore &ds){
loop:
	fm.recoverPattern();
	Display::loopReminder();
	std::string userinput;
	std::getline(std::cin, userinput);
	// an enter without any text would lead to exit
	if (userinput == ""){
		exit(0);
	}
	Exec::setpatt(fm, userinput);
	searchText(fm, ds, fInLoop(userinput));
	goto loop;
}

// ----< test stub >--------------------------------------------------------
#ifdef TEST_CATALOGUE

int main()
{
	std::cout << "\n  Testing Catalogue class";
	std::cout << "\n =======================\n";
	std::cout << "\n  Give a path: d:/debug\n";
	std::cout << "\n  And command /d /s /f \n";
	DataStore ds;
	FileMgr fm("D:/debug", ds);
	Exec::setpatt(fm, "D:/debug  /d /s /f\"haha\"");
	Catalogue::process(fm, ds, "D:/debug  /d /s /f\"haha\"");
	//recover patterns, add patt and search text again.
	Catalogue::loop(fm, ds);
	return 0;
}

#endif