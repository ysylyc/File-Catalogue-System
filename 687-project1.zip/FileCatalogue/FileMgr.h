#ifndef FILEMGR_H
#define FILEMGR_H

// FileMgr.h - Collects file specifications from directory tree

#include "FileSystem.h"
#include "DataStore.h"
#include <vector>
#include <string>

class FileMgr
{
public:
  using iterator = DataStore::iterator;
  using patterns = std::vector < std::string > ;
  // construction function
  FileMgr(const std::string& path, DataStore& store) : path_(path), store_(store)
  {
    patterns_.push_back("*.*");
  }
  void addPattern(const std::string& patt)
  {
    if (patterns_.size() == 1 && patterns_[0] == "*.*")
      patterns_.pop_back();
    patterns_.push_back(patt);
  }
  // make the pattern to the original type
  void recoverPattern(){ patterns_.clear(); patterns_.push_back("*.*"); }
  std::string getPatt();
  void initializeSearch(int onOroff);
  void find(const std::string&path, int onOroff);
  iterator begin() { return store_.begin(); }
  iterator end() { return store_.end(); }

private:
  DataStore& store_;
  std::string path_;
  patterns patterns_;
};
#endif
