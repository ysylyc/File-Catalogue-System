#ifndef DISPLAY_H
#define DISPLAY_H
/////////////////////////////////////////////////////////////////////////////
// Display.h - Display the result, summary and reminder                    //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Catalogue.h"

class Display{
public:
	enum satisfied { DEFAULT, DUPLICATION, SEARCHED };
	static void summary(size_t fileNum, size_t dirNum, satisfied userCommand);
	static void reminder();
	static void loopReminder();
	static void printResultD(const std::string &filename, const DataStore::ListOfIters &listOfPaths);
	static void printResultF(const std::string &filename, const std::string &path);
};
#endif