#include "DataStore.h"
#include "FileSystem.h"
#include <iostream>

// Save file name and path to DataStore from filespec
void DataStore::save(const std::string& filespec){
	std::string pathtmp = FileSystem::Path::getPath(filespec);
	std::string nametmp = FileSystem::Path::getName(filespec, true);
	save(nametmp, pathtmp);
}

// Save file name and path to DataStore
void DataStore::save(const std::string& filename, const std::string& path){
	std::pair<PathIter, bool> p;
	p = paths.insert(path);
	// fing the duplicate filename first, if exists
	auto search = store.find(filename);
	// if the filename is the first time appearance
	if (search == store.end()){
		// make a new list
		ListOfIters listtmp;
		listtmp.push_back(p.first);
		store.insert(Store::value_type(filename, listtmp));
	}
	else {
		// if the file's list already exists
		if (p.second == true)
		search->second.push_back(p.first);
	}
}

// Get the file quantity of current DataStore
size_t DataStore::getFileNum(){
	int count = 0;
	// get key first
	for (auto i : store){
		// then check the corresponding mapping value
		for (auto j : i.second){
			count++;
		}
	}
	return count;
}

// ----< test stub >--------------------------------------------------------
#ifdef TEST_DATASTORE

int main()
{
	DataStore ds;
	ds.save("one","d:/debug");
	ds.save("two","d:/debug");
	ds.save("three","d:/debug");

	DataStore::iterator iter = ds.begin();
	std::cout << "\n  first file of ds is: \"" << *iter << "\"\n";
	for (auto elem : ds)
	{
		std::cout << "\n  " << elem.first;
	}
	std::cout << "there are "<< getFileNum() <<" files totally.\n";
	std::cout << "there are "<< getDirNum() <<" directories totally.\n";
	std::cout << "\n\n";
	return 0;
}

#endif