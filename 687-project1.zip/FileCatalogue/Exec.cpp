/////////////////////////////////////////////////////////////////////////////
// Exec.h - Get input from user and set basic parameters, also includes    //
//			some string operation functions.                               //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Exec.h"
#include "FileSystem.h"
#include "Catalogue.h"
#include "Display.h"
#include <iostream>
#include <sstream>

// find a substr from a string, return true if found
bool Exec::findstr(const std::string& getuserinput, const std::string& str){
	std::string::size_type n = getuserinput.find(str);
	return (n == std::string::npos) ? false : true;
}

// split a string depends on a specific delim
std::vector<std::string>& Exec::split(const std::string &s, char delim, std::vector<std::string> &elems) {
	std::stringstream ss(s);
	std::string item;
	while (std::getline(ss, item, delim)) {
		elems.push_back(item);
	}
	return elems;
}

// get path from user input
std::string Exec::getpath(const std::string& getuserinput){
	std::string path;
	// we think the first must be a path
	std::string::size_type n = getuserinput.find(" ");
	// if there is no whitespace, the whole string is a path
	if (n == std::string::npos){
		path = getuserinput;
	}
	else{
		path = getuserinput.substr(0, n);
	}
	checkPath(path);
	return path;
}

// set the path to current path if user path is incorrect
void Exec::checkPath(std::string& path){
	if (!FileSystem::Directory::exists(path)){
		path = ".";
		std::cout << "***********error path, set default path.***********\n\n";
	}
}

// set pattern from user input
void Exec::setpatt(FileMgr &fm, const std::string& getuserinput){
	std::vector<std::string> needanalysis, patt;
	// split string depends on whitespace
	Exec::split(getuserinput, ' ', needanalysis);
	// an iterator of vector needanalysis
	for (auto tmp : needanalysis){
		if (findstr(tmp, "*.")){
			fm.addPattern(tmp);
		}
	}
	return;
}

// ----< main function >--------------------------------------------------------

int main(int argc, char* argv[]){
	Display::reminder();
	std::string userinput, targetpath;
	std::getline(std::cin, userinput);
	targetpath = Exec::getpath(userinput);
	DataStore ds;
	FileMgr fm(targetpath, ds);
	Exec::setpatt(fm, userinput);
	Catalogue::process(fm, ds, userinput);
	//recover patterns, add patt and search text again.
	Catalogue::loop(fm, ds);
	return 0;
}

