#ifndef DATASTORE_H
#define DATASTORE_H

// DataStore.h - for DataStore class

#include <string>
#include <set>
#include <list>
#include <map>

class DataStore
{
public:
	using Path = std::string;
	using Paths = std::set < Path > ;
	using PathIter = Paths::iterator;
	using ListOfIters = std::list < PathIter > ;
	using File = std::string;
	using Store = std::map < File, ListOfIters > ;
	using iterator = Store::iterator;

	void save(const std::string& filespec);
	void save(const std::string& filename, const std::string& path);
	size_t getFileNum();
	// Get the directory quantity of current DataStore
	size_t getDirNum(){ return paths.size(); }
	iterator begin() { return store.begin(); }
	iterator end() { return store.end(); }
private:
	Store store;	// to store file name
	Paths paths;	// to store file path
};
#endif