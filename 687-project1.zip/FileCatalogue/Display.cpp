/////////////////////////////////////////////////////////////////////////////
// Display.h - Display the result, summary and reminder                    //
// ver 1.0                                                                 //
// ----------------------------------------------------------------------- //
// copyright ?Siyuan(Jeremy) Ye, 2015                                      //
// All rights granted provided that this notice is retained                //
// ----------------------------------------------------------------------- //
// Application: Spring Assignment Projects, 2015                           //
// Author:      Siyuan(Jeremy) Ye, Syracuse University                     //
/////////////////////////////////////////////////////////////////////////////
#include "Display.h"
#include "DataStore.h"

// output the summary depends on userCommand
void Display::summary(size_t fileNum, size_t dirNum, satisfied userCommand){
	switch (userCommand)
	{
	case Display::DEFAULT:
		std::cout << "Total summary: " << fileNum << " Files found in " << dirNum << " directories.\n\n";
		break;
	case Display::DUPLICATION:
		std::cout << "There are " << fileNum << " duplicate name files found in " << dirNum << " directories.\n\n";
		break;
	case Display::SEARCHED:
		std::cout << "The text are found in " << fileNum << " files in " << dirNum << " directories.\n\n";
		break;
	default:
		break;
	}
}

// output the main notice for user
void Display::reminder(){
	std::cout << "\nFile Catalogue System";
	std::cout << "\n=======================\n";
	std::cout << "Please input a path and add options\n";
	std::cout << "/s search matching files in the entire directory tree rooted at the path.\n";
	std::cout << "/d show a list of duplicate file names with their paths.\n";
	std::cout << "/f\"search text\" list all the files stored in the catalog that contain the search text.\n";
	std::cout << "****a wrong path would be corrected to a current path automatically.\n";
	std::cout << "****a wrong command would be ignored.\n";
	std::cout << "****default option would emit a brief summary.\n" << std::endl;
}

// output the loop notice for user
void Display::loopReminder(){
	std::cout << "====Please provide \"text\" and file pattern(s) you want to search.====\n";
	std::cout << "****An enter with no text would exit system.\n";
}

// output the result of command "/d"
void Display::printResultD(const std::string &filename, const DataStore::ListOfIters &listOfPaths){
	std::cout << "Duplicate file name: " << filename << std::endl;
	std::cout << "File paths: \n";
	for (auto tmpPath : listOfPaths){
		std::cout << *tmpPath << std::endl;
	}
}

// output the result of command "/f"
void Display::printResultF(const std::string &filename, const std::string &path){
	std::cout << "file name: " << filename
		<< "(path: " << path << ")\n";
}

// ----< test stub >--------------------------------------------------------
#ifdef TEST_DISPLAY

int main()
{
	std::cout << "\n  Testing Display class";
	std::cout << "\n =======================\n";
	std::cout << "\n  Testing reminder and loop reminder\n";
	reminder();
	loopReminder();
	DataStore ds;
	ds.save("one","d:/debug");
	ds.save("one","d:/debug/123");
	ds.save("three", "d:/debug");
	for(auto tmpfilename : ds){
		printResultD("one", tmpfilename.second);
	}
	printResultF("three", "d:/debug");
	return 0;
}

#endif